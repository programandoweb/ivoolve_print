Paquete de instalación de impresora

Archivos:
- setup-printer.ps1
- setup-printer.bat
- printer-profile.reg.example

Uso:
1. Asegúrate de que el driver "Gainscha GI-2406T PLUS" esté instalado.
2. Asegúrate de que exista el puerto "USB001".
3. Haz doble clic en setup-printer.bat
4. El script creará la impresora "Gainscha GI-2406T Jorge" si no existe.
5. Si agregas un archivo llamado printer-profile.reg en esta misma carpeta, el script intentará importarlo.

Notas:
- Debe ejecutarse como administrador.
- El script no reinstala drivers.
- La configuración avanzada del driver (tamaño personalizado, orientación, densidad, etc.) depende del driver y puede requerir exportación/importación adicional del perfil.
