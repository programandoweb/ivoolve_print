@echo off
setlocal

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Este instalador requiere permisos de administrador.
    echo Intentando elevar permisos...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

powershell -ExecutionPolicy Bypass -File "%~dp0setup-printer.ps1"

echo.
if %errorlevel% equ 0 (
    echo Proceso finalizado correctamente.
) else (
    echo El proceso terminó con errores.
)
echo.
pause
