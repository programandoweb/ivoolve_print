#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

$printerName = "Gainscha GI-2406T Jorge"
$driverName  = "Gainscha GI-2406T PLUS"
$portName    = "USB001"
$shareName   = "Gainscha GI-2406T Jorge"
$regFile     = Join-Path $PSScriptRoot 'printer-profile.reg'

function Write-Step($message) {
    Write-Host "[INFO] $message" -ForegroundColor Cyan
}

function Write-Ok($message) {
    Write-Host "[OK] $message" -ForegroundColor Green
}

function Write-WarnMsg($message) {
    Write-Host "[WARN] $message" -ForegroundColor Yellow
}

function Write-ErrMsg($message) {
    Write-Host "[ERROR] $message" -ForegroundColor Red
}

try {
    Write-Step "Validando permisos de administrador..."
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        throw "Debes ejecutar este script como administrador."
    }
    Write-Ok "Permisos correctos."

    Write-Step "Verificando driver: $driverName"
    $driver = Get-PrinterDriver -Name $driverName -ErrorAction SilentlyContinue
    if ($null -eq $driver) {
        throw "No existe el driver '$driverName'. Instálalo primero."
    }
    Write-Ok "Driver encontrado."

    Write-Step "Verificando puerto: $portName"
    $port = Get-PrinterPort -Name $portName -ErrorAction SilentlyContinue
    if ($null -eq $port) {
        throw "No existe el puerto '$portName'. Conecta la impresora o crea el puerto antes de continuar."
    }
    Write-Ok "Puerto encontrado."

    Write-Step "Verificando impresora: $printerName"
    $printer = Get-Printer -Name $printerName -ErrorAction SilentlyContinue

    if ($null -eq $printer) {
        Write-Step "La impresora no existe. Creándola..."
        Add-Printer -Name $printerName -DriverName $driverName -PortName $portName | Out-Null
        Write-Ok "Impresora creada."
    }
    else {
        Write-Ok "La impresora ya existe. No se crea de nuevo."
    }

    Write-Step "Actualizando propiedades principales..."
    Set-Printer -Name $printerName -DriverName $driverName -PortName $portName -Shared $true -ShareName $shareName | Out-Null
    Write-Ok "Propiedades principales aplicadas."

    if (Test-Path $regFile) {
        Write-Step "Se encontró printer-profile.reg. Intentando importar configuración adicional..."
        reg import $regFile | Out-Null
        Write-Ok "Registro importado."
    }
    else {
        Write-WarnMsg "No se encontró printer-profile.reg. Se omite importación de registro."
    }

    Write-Step "Estado final:"
    Get-Printer -Name $printerName | Format-List Name, DriverName, PortName, Shared, ShareName

    Write-Ok "Proceso completado."
    Write-WarnMsg "Si necesitas tamaño personalizado, orientación o preferencias avanzadas del driver, aplícalas luego desde el perfil del driver o exporta/importa DEVMODE del mismo equipo."
}
catch {
    Write-ErrMsg $_.Exception.Message
    exit 1
}
